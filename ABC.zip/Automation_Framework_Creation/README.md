# Automation_Framework_Creation

This repository project is created to contain artifacts of "Automation Framework creation" challenge.