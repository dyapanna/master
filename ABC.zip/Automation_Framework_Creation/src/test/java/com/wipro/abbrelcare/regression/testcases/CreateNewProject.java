package com.wipro.abbrelcare.regression.testcases;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.wipro.abbrelcare.pageObjects.CreateNewProjectPage;
import com.wipro.abbrelcare.pageObjects.HomePages;
import com.wipro.abbrelcare.pageObjects.LoginPagePages;
import com.wipro.abbrelcare.pageObjects.SystemManagerAllProjects;
import com.wipro.abbrelcare.setup.BaseTestPage;
import com.wipro.abbrelcare.utility.AbbRelCareSynchronization;
import com.wipro.abbrelcare.utility.AbbRelCareVerification;
import com.wipro.abbrelcare.utility.CommonMethods;

public class CreateNewProject extends BaseTestPage {
	
	public static String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
	public static String ClientName = "AutomationClient" + timeStamp;
	public static String ProjName = "AutomationProj" + timeStamp;
	
	
	@Test(priority = 1,description="Invalid Login Scenario with wrong username and password.")
	public void testLoginPageElements() {
		
		LoginPagePages loginPage = new LoginPagePages(driver);
		try {
			AbbRelCareVerification.verifyElementPresent(driver, loginPage.textBoxEmail);
			AbbRelCareVerification.verifyIsEnable(driver, loginPage.textBoxEmail);
		} catch (Exception e) {

			e.printStackTrace();
		}

		AbbRelCareVerification.endofTestcase();
	}

	@Test(priority = 2)
	public void testLoginButton() throws NoSuchElementException {
		
		LoginPagePages loginPage = new LoginPagePages(driver);

		try {
			AbbRelCareVerification.verifyElementPresent(driver, loginPage.buttonLogin);
		} catch (Exception ex) {

			ex.printStackTrace();
		}

	}

	//  Verify System Manager user is able to Create a new project	

	@Test(priority = 1)
	public void US_21_1_TC01() throws Exception {
		
		
		try {
			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(smuserName, passWord);
			SystemManagerAllProjects allProjects = new SystemManagerAllProjects(driver);
			AbbRelCareSynchronization.waitElement(driver, allProjects.textAllProjects);
			HomePages homePage = new HomePages(driver);
			String expLandPage = driver.getCurrentUrl();
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			Thread.sleep(8000);
			AbbRelCareVerification.verifyString(expLandPage, homePage.expURL);
			
			
			AbbRelCareVerification.verifyText(allProjects.textAllProjects, allProjects.expTitle);
			allProjects.linkCreateNew.click();
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			//Thread.sleep(8000);
			
			CreateNewProjectPage createNewProj = new  CreateNewProjectPage(driver);
			//Enter values for Client details
			createNewProj.inputName.click();
			createNewProj.inputName.sendKeys(ClientName);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectArea, "Europe");
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			//Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectCountry, "Spain");
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			//Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectState, "Sevilla");
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			//Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectCity, "Sevilla");
			
			//Enter values for Project details
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", createNewProj.textBoxName);
			createNewProj.textBoxName.sendKeys(ProjName);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownType,"Industrial");
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			//Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownCurrency,"USD");
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			//Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownDecimaldelimiter,".");
			Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownDiagramsymbols,"ANSI");
			Thread.sleep(4000);
			//Enter values for Commercial Scope
			
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectStartDay,"2");
			Thread.sleep(1000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectStartMonth,"Mar");
			Thread.sleep(1000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectStartYear,"2019");
			Thread.sleep(1000);
			
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectEndDay,"2");
			Thread.sleep(1000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectEndMonth,"Mar");
			Thread.sleep(1000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(createNewProj.dropDownSelectEndYear,"2020");
			Thread.sleep(1000);
			
			js.executeScript("arguments[0].scrollIntoView();", createNewProj.linkAssignMember);
			createNewProj.linkAssignMember.click();
			Thread.sleep(4000);
			AbbRelCareSynchronization.waitElement(driver, createNewProj.textFieldSearch);
			createNewProj.textFieldSearch.sendKeys("Venkatesh");
			Thread.sleep(4000);
			AbbRelCareSynchronization.waitElement(driver, createNewProj.checkBoxMember);
			createNewProj.checkBoxMember.click();
			createNewProj.buttonAssign.click();
			Thread.sleep(4000);
			createNewProj.buttonSave.click();
			Thread.sleep(4000);
			//String actSuccessMsg = driver.switchTo().alert().getText();
			AbbRelCareVerification.verifyText(createNewProj.textSuccessMessage, createNewProj.expSuccesMsg);
			driver.switchTo().alert().accept();
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Reporter.log("FAIL " + e.getMessage());
			System.out.println("FAIL : "+e.getMessage());
			
		}
		
	}

}
