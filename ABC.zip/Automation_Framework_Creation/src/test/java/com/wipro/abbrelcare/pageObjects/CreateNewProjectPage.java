package com.wipro.abbrelcare.pageObjects;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.wipro.abbrelcare.setup.BasePage;


public class CreateNewProjectPage extends BasePage {

	
	public CreateNewProjectPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public static String expSuccesMsg = "Project created successfully!";
	//PAges for Client details
	public static List<String> expAssignMembersTableHeaders = Arrays.asList("Member","Role","Employer","Email","Phone");
	@FindBy(xpath = "//h5[contains(text(),'Client details')]")
	public WebElement textClientDetails;
	
	@FindBy(xpath = "//div[@class='col-lg-7']//input[@class='form-input ng-untouched ng-pristine ng-invalid']")
	public WebElement inputName;
	
	@FindBy(xpath = "//select[@formcontrolname='area']")
	public WebElement dropDownSelectArea;
	
	@FindBy(xpath = "//select[@formcontrolname='country']")
	public WebElement dropDownSelectCountry;
	
	@FindBy(xpath = "//select[@formcontrolname='state']")
	public WebElement dropDownSelectState;
	
	@FindBy(xpath = "//select[@formcontrolname='city']")
	public WebElement dropDownSelectCity;
	
	@FindBy(xpath = "//i[@class='icon icon-add-new']")
	public WebElement linkAssignMember;
	
	@FindBy(xpath = "//span[@class='datatable-header-cell-wrapper']")
	public List<WebElement> tableHeadersAssignMembers;
	
	@FindBy(xpath = "//input[@placeholder='Search']")
	public WebElement textFieldSearch;
	
	@FindBy(xpath = "//label[@class='checkbox-wrap']")
	public WebElement checkBoxMember;
	
	@FindBy(xpath = "//a[text()='Assign']")
	public WebElement buttonAssign;
	
	@FindBy(xpath = "//h5[contains(text(),'Members')]")
	public WebElement textMembers;
	
	
	// Project Details
	@FindBy(xpath = "//h5[contains(text(),'Project details')]")
	public WebElement textProjectDetails;
	
	@FindBy(xpath = "//input[@formcontrolname='projectName']")
	public WebElement textBoxName;
	
	@FindBy(xpath = "//select[@formcontrolname='projectType']")
	public WebElement dropDownType;
	
	@FindBy(xpath = "//select[@formcontrolname='projectCurrency']")
	public WebElement dropDownCurrency;
	
	@FindBy(xpath = "//select[@formcontrolname='decimalDelimiter']")
	public WebElement dropDownDecimaldelimiter;
	
	@FindBy(xpath = "//select[@formcontrolname='diagramSymbols']")
	public WebElement dropDownDiagramsymbols;
	
	
	
	
	
	//Commercial scope
	@FindBy(xpath = "//h5[contains(text(),'Commercial Scope')]")
	public WebElement textCommercialScope;
	
	@FindBy(xpath = "//select[@formcontrolname='startD']")
	public WebElement dropDownSelectStartDay;
	
	@FindBy(xpath = "//select[@formcontrolname='startM']")
	public WebElement dropDownSelectStartMonth;
	
	@FindBy(xpath = "//select[@formcontrolname='startY']")
	public WebElement dropDownSelectStartYear;
	
	@FindBy(xpath = "//select[@formcontrolname='endD']")
	public WebElement dropDownSelectEndDay;
	
	@FindBy(xpath = "//select[@formcontrolname='endM']")
	public WebElement dropDownSelectEndMonth;
	
	@FindBy(xpath = "//select[@formcontrolname='endY']")
	public WebElement dropDownSelectEndYear;
	
	
	@FindBy(xpath = "//button[text()='Save']")
	public WebElement buttonSave;
	
	@FindBy(xpath = "//span[text()='Project created successfully!']")
	public WebElement textSuccessMessage;
	
	@FindBy(xpath = "//a[@class='btn btn-cancel']")
	public WebElement buttonOK;
	
	
	

}
