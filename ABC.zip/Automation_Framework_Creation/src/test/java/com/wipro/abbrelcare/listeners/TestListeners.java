package com.wipro.abbrelcare.listeners;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.IResultMap;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.wipro.abbrelcare.setup.BaseTestPage;
import com.wipro.abbrelcare.utility.EmailReport;


public class TestListeners extends BaseTestPage implements ITestListener{


	//private WebDriver driver ;
	public static ExtentReports reports;
	public static ExtentTest logger;
	public static int tcCount = 0; 
	String currnetlocation = System.getProperty("user.dir");
	public String filePath = currnetlocation + "\\ScreenShots\\";
	private static String fileSeperator = System.getProperty("file.separator");
	List<String> recipients  = Arrays.asList("venkatesh.c84@wipro.com");
	public String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss").format(new Date());
	 
	JSONParser parser = new JSONParser();
		
	private static String getTestMethodName(ITestResult iTestResult) {
        return iTestResult.getMethod().getConstructorOrMethod().getName();
    }
	
	
	public void onTestStart(ITestResult result) {
		String methodName = result.getName().toString().trim();
		System.out.println("Started Test Method -->" +methodName);
		logger = reports.startTest(result.getMethod().getMethodName());
		logger.log(LogStatus.INFO, result.getMethod().getMethodName() + "test is started");
		tcCount++; 
		
	}
	public void onTestSuccess(ITestResult result) {
		Reporter.log("Test case PAssed "+result.getTestName());
		logger.log(LogStatus.PASS, result.getMethod().getMethodName() + "test is passed");
		
	}

	public void onTestFailure(ITestResult result) {
		System.out.println("***** Error " + result.getName() + " test has failed *****");
		String methodName = result.getName().toString().trim();
		takeScreenShot(methodName);
		logger.log(LogStatus.FAIL, result.getMethod().getMethodName() + "test is Failed");
	}

	public void takeScreenShot(String methodName) {
		// get the driver
	//	BaseTestPage base = new BaseTestPage();
		//driver=base.getDriver();
		String fileName = new Date().getTime() + ".png";
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(filePath + methodName + fileName));
			System.out.println("***Placed screen shot in " + filePath + " ***");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void onTestSkipped(ITestResult result) {
		logger.log(LogStatus.SKIP, result.getMethod().getMethodName() + "test is skipped");
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		String fileName =System.getProperty("user.dir") + "\\test-output\\"+ new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss-ms").format(new Date()) + "Reports.html";
		reports = new ExtentReports(fileName);
		System.out.println("$Reports file name : "+fileName);
		context.setAttribute("fileName", fileName);
	}

	public void onFinish(ITestContext context) {
		String fileName = (String) context.getAttribute("fileName");
		reports.endTest(logger);
		reports.flush();
	/*	try {
			JSONParser parser = new JSONParser();
			Object object = parser.parse(new FileReader(currnetlocation + "\\propertiesFile\\Users.json"));
			JSONObject jsonObject = (JSONObject)object;
			JSONArray recipients = (JSONArray)jsonObject.get("recipients");
			System.out.println("Mailed to below users"+recipients);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}*/
	//	EmailReport.sendPDFReportByGMail("testdiverseywipro@gmail.com", "D!versey2018", recipients, "ABB RelCare Regression Report  "+String.valueOf( timeStamp), "",fileName);
		
		 }

}
