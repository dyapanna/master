package com.wipro.abbrelcare.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ReadFileData {

	Properties prop = new Properties();
	InputStream input = null;
	public String qaURL = null;
	public String devURL = null;
	public String prodURL = null;
	public String testUrl;
	public static String smuserName;
	public static String pmuserName;
	public static String passWord;

	public ReadFileData() {
		try {
			String currnetlocation = System.getProperty("user.dir");
			input = new FileInputStream(currnetlocation + "/propertiesFile/application.properties");

			prop.load(input);
			smuserName = prop.getProperty("SMuserName");
			pmuserName = prop.getProperty("PMuserName");
			passWord = prop.getProperty("passWord");
			testUrl = prop.getProperty("testUrl");
			// ystem.out.println(testUrl +userName +passWord);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getUrl() {
		return testUrl;

	}

}