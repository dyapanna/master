package com.wipro.abbrelcare.smoke.testcases;

import com.wipro.abbrelcare.setup.BaseTestPage;

public class SmokeTestCases extends BaseTestPage {

}
