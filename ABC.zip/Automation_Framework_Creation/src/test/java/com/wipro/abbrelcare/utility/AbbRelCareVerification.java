package com.wipro.abbrelcare.utility;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.media.jfxmedia.logging.Logger;
import com.wipro.abbrelcare.setup.BasePage;
import com.wipro.abbrelcare.listeners.TestListeners;

public class AbbRelCareVerification extends TestListeners {
	
	public static String res="PASS : All elemenmts present ";
	public static SoftAssert softAssert = new SoftAssert();
	static String currnetlocation = System.getProperty("user.dir");
	public static String downloadPath = currnetlocation + "/FileDownloads";

//Comparing two lists as string	
	public static void verifyTwoList(String actList, String expList) {
		if (actList.equals(expList)) {
			Reporter.log(res + expList.toString());
			System.out.println(res + expList.toString());
		} else {
			Reporter.log("FAIL : All elemenmts not present Actual List " + actList.toString() + "\n Expected List"
					+ expList);
			System.out.println("FAIL : All elemenmts not present Actual List :" + actList.toString()
					+ "\n Expected List" + expList);
			softAssert.assertEquals(actList, expList);
			softAssert.assertAll();
		}
	}

	// Comparing two lists
	public static void verifyTwoLists(List actList, List expList) {
		if (actList.equals(expList)) {
			Reporter.log("PASS : All elemenmts present " + expList.toString());
			System.out.println("PASS : All elemenmts present " + expList.toString());
			softAssert.assertTrue(true);
		} else {
			Reporter.log("FAIL : All elemenmts not present Actual List " + actList.toString() + "\n Expected List"
					+ expList);
			System.out.println("FAIL : All elemenmts not present Actual List :" + actList.toString()
					+ "\n Expected List" + expList);
			softAssert.assertTrue(false);
			//softAssert.assertEquals(actList, expList);
		//	softAssert.assertAll();
		}
	}

	public static void verifyText(WebElement locator, String expectedText) throws NoSuchElementException {
		String actualText;
		try {
			actualText = locator.getText();
			if (actualText.equals(expectedText)) {
				Reporter.log("Passed : Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
				
				System.out
						.println("Passed : Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
				//logger.log(LogStatus.PASS," Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
				
				// softAssert.assertEquals(actualText, expectedText);
			} else {
				Reporter.log("Failed : Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
				System.out
						.println("Failed : Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
				//logger.log(LogStatus.FAIL," Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
				softAssert.assertEquals(actualText, expectedText);
				softAssert.assertAll();
			//	throw new Exception("Expected string not matched" + actualText);
			}
		} catch (Exception error) {
			error.printStackTrace();
			Reporter.log(error.getMessage());
		}
	}

	public static void verifyString(String actualText, String expectedText) {

		try {
			if (actualText.equals(expectedText)) {
				Reporter.log("Passed : Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
				System.out.println("Passed : Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
			//	logger.log(LogStatus.PASS, "Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
			} else {
				Reporter.log("Failed : Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");
				//logger.log(LogStatus.FAIL, "Actual Text "+actualText+" Expected Text "+expectedText+"");
				System.out
						.println("Failed : Actual Text:= [" + actualText + "] Expected Text:= [" + expectedText + "]");

				softAssert.assertEquals(actualText, expectedText);
				softAssert.assertAll();
				throw new Exception("Expected string not matched" + actualText);
				
			}
		} catch (Exception error) {
			error.printStackTrace();
			Reporter.log(error.getMessage());
			
		}
		
	}
	
	public static void verifyListContainsText(List<String> actList,String text) throws Exception {
		boolean result = actList.contains(text);
		if(result = true) {
			Reporter.log("PASS :" +text + "Role created Successfully");
		//	logger.log(LogStatus.PASS, text + "Role created Successfully");
			System.out.println(text + "Role created Successfully");
		}else {
			Reporter.log("FAIL :" +text + "Role not created Successfully");
		//	logger.log(LogStatus.FAIL, text + "Role not created Successfully");
			System.out.println(text + "Not created");
			softAssert.assertEquals(actList, text);
			softAssert.assertAll();
			throw new Exception("Expected string not matched" + text);
		}
	}

// To verify invalid links in page

	public static void verifyInvalidUrls(List<WebElement> locator) {
		try {

			int invalidLinksCount = 0;
			List<WebElement> allLinks = locator;

			System.out.println("Total no. of links are " + allLinks.size());
			for (WebElement link : allLinks) {

				if (link != null) {
					String url = link.getAttribute("href");
					System.out.println("URL :" + url);
					if (url != null && !url.contains("javascript")) {
						CommonMethods.veriyfURLStatus(url);
					} else {
						String inurl = link.getAttribute("href");
						System.out.println("Total no. of invalid links are " + inurl);
						invalidLinksCount++;

					}

				}

			}

			if (invalidLinksCount > 0) {
				Reporter.log("FAIL Total no. of invalid links are " + invalidLinksCount);
				System.out.println("FAIL Total no. of invalid links are " + invalidLinksCount);

			} else {
				Reporter.log(
						"PASS There are no invalid links in the current page, out of total links " + allLinks.size());
				System.out.println(
						"PASS There are no invalid links in the current page, out of total links:" + allLinks.size());
			//	softAssert.assertEquals(invalidLinksCount, invalidLinksCount);
				softAssert.assertAll();
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

// Method to check attribute of class
	public static void verifyHasClass(WebDriver driver, WebElement element, String value) {
		String classes = element.getAttribute("class");

		if (classes.contains(value)) {
			Reporter.log("Passed : Element := [" + element.getText() + "] is Highlighted");
			System.out.println("Passed : Element:= [" + element.getText() + "] is Highlighted");
			softAssert.assertTrue(true);
		} else {

			Reporter.log("Failed : Element:= [" + element.getText() + "] is not Highlighted");
			System.out.println("Failed : Element:= [" + element.getText() + "] is not Highlighted");
			softAssert.assertTrue(false);
			softAssert.assertAll();
		}

	}

	// Method to check attribute of class
	public static void verifyHasClassInactive(WebDriver driver, WebElement element, String value) {
		String classes = element.getAttribute("class");
		for (String c : classes.split("-")) {
			if (c.equals(value)) {
				Reporter.log("Failed : Actual Class:= [" + classes + "] Expected Class:= [" + value + "]");
				System.out.println("Failed : Actual Class:= [" + classes + "] Expected Class:= [" + value + "]");
				softAssert.assertTrue(true);
			}
		}

		Reporter.log(" Passed: Actual Class:= [" + classes + "] Expected Class:= [" + value + "]");
		System.out.println("Passed : Actual Class:= [" + classes + "] Expected Class doesnot have := [" + value + "]");
		softAssert.assertTrue(false);
	}

	public static void verifyElementPresent(WebDriver driver, WebElement locator) throws Exception {
		try {

			if (locator.isDisplayed()) {
				Reporter.log(locator.getText() + "PASS Element is Displayed");
				System.out.println(locator.getText() + "PASS Element is Displayed");
				//softAssert.assertTrue(true);
				
				
			//	logger.log(LogStatus.PASS, "Element is Displayed");
			}

		} catch (NoSuchElementException error) {
		  // softAssert.assertTrue(false);
			softAssert.fail();
			Reporter.log(locator.getAttribute("value") + " Element is not Displayed");
		//	logger.log(LogStatus.FAIL,locator.toString() + " Element is not Displayed");
			System.out.println(locator.getAttribute("value") + " Element is not Displayed");
		//	throw new Exception(locator.getAttribute("value") + "Element is not Displayed");

		}
	//	softAssert.assertAll();
	}

	public static void verifyMemberPresent(WebDriver driver, WebElement locator) throws Exception {
		try {

			if (locator.isDisplayed()) {
				Reporter.log(locator.getText() + "PASS Element is Displayed");
				System.out.println(locator.getText() + "PASS Element is Displayed");
				softAssert.assertTrue(true);
				
			//	logger.log(LogStatus.PASS, "Element is Displayed");
			}

		} catch (NoSuchElementException error) {
			softAssert.assertTrue(false);
			Reporter.log(locator.getAttribute("value") + " Element is not Displayed");
		//	logger.log(LogStatus.FAIL,locator.toString() + " Element is not Displayed");
			System.out.println(locator.getAttribute("value") + " Element is not Displayed");
		//	throw new Exception(locator.getAttribute("value") + "Element is not Displayed");

		}

	}
	
	
	public static void verifyElementNotPresent(WebDriver driver, WebElement  locator) throws Exception {
		
		try {
		 
			if (locator.isDisplayed()) {
				
				 Reporter.log(locator.toString() + " Failed Element is Displayed");
				 System.out.println(locator.toString() + " Failed Element is Displayed");
				// logger.log(LogStatus.FAIL,locator.toString() + " Failed Element is Displayed");
				 softAssert.assertTrue(false);
			  }
			  
			  } catch (NoSuchElementException error) {
				  softAssert.assertTrue(true);
			 	  Reporter.log(" Passed Element is not Displayed");
			 	  System.out.println("Element not Present");
			//  logger.log(LogStatus.PASS,locator.toString() + " Failed Element is Displayed");
			  throw new Exception(locator.getAttribute("value") + "Element is not Displayed");
			  }
			  
	  }
	
	
	// To verify Alert present
	public static void verifyIsAlertPresent(WebDriver driver) {
		try {
			driver.switchTo().alert();
			softAssert.assertTrue(true);
			Reporter.log("Alert is Present");
		} catch (NoAlertPresentException Ex) {
			softAssert.assertTrue(false);
			Reporter.log("Alert is not Present");
		}

	}

	public static void verifyAttribute(WebDriver driver, WebElement locator, String value, String expected)
			throws Exception {

		try {
			String actValue = locator.getAttribute(value);
			if (actValue.equalsIgnoreCase(expected)) {
				softAssert.assertTrue(true);
				Reporter.log("Attributes are matched");
			} else {

				softAssert.assertTrue(false);
				Reporter.log("Attributes are not matched");
			}
		} catch (Exception e) {
			throw new Exception("No such element present");
		}
	}

	public static void verifyIsEnable(WebDriver driver, WebElement locator) {
		try {
			if (locator.isEnabled()) {
				Reporter.log("PASS :" + locator.toString() + "is enabled");
				System.out.println("PASS :" + locator.toString() + "is enabled");
				softAssert.assertTrue(true);
			} else {
				Reporter.log("FAIL :" + locator.toString() + "is disabled");
				System.out.println("FAIL :" + locator.toString() + "is disabled");
				softAssert.assertTrue(false);
			}

		} catch (Exception e) {

		}

	}

	public static void verifyAttribute(WebDriver driver, WebElement locator, String expected) throws Exception {

		try {
			String actValue = locator.getAttribute("placeholder");
			if (actValue.equalsIgnoreCase(expected)) {
				softAssert.assertTrue(true);
				Reporter.log("Attributes are matched");
			} else {

				softAssert.assertTrue(false);
				Reporter.log("Attributes are not matched");
			}
		} catch (Exception e) {
			throw new Exception("No such element present");
		}
	}

	// To display invalid/non existing elements from list

	public static void verifyComparedList(List<String> expectedList, List<String> sourceList, String listName) {

		try {
			for (String expecteditem : expectedList) {
				if (!sourceList.contains(expecteditem)) {
					System.out.println("Not present in " + listName + " list:" + expecteditem);
					Reporter.log("Failed : Below items not present " + listName + " list : " + expecteditem);
					softAssert.assertTrue(false);
				} else {
					Reporter.log("Passed : All items  present " + listName + " list : " + expecteditem);
					softAssert.assertTrue(true);
				}
			}
		} catch (Exception e) {

		}

	}

	// To verify element is clickable
	public static void verifyIsClickable(WebDriver driver, WebElement locator) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.elementToBeClickable((By) locator));
			System.out.println("Element is clickable " + locator.toString());
			Reporter.log("Passed : Element is clickable " + locator.toString());
			softAssert.assertTrue(true);
		} catch (Exception e) {
			System.out.println("Element is not clickable " + locator.toString());
			Reporter.log("Failed :Element is not clickable " + locator.toString());
			softAssert.assertTrue(false);
		}
	}

	public static void verifyImageLoaded(WebDriver driver) {
		try {
			int invalidImageCount = 0;
			List<WebElement> imagesList = driver.findElements(By.tagName("img"));
			System.out.println("Total no. of images are " + imagesList.size());
			for (WebElement imgElement : imagesList) {
				if (imgElement != null) {
					CommonMethods.verifyimageActive(imgElement);
				}
			}
			if (invalidImageCount > 0) {
				System.out.println("Total no. of invalid images are " + invalidImageCount);
				Reporter.log("Failed : All Images are not loaded, count of invalid images are : " + invalidImageCount);
				logger.log(LogStatus.FAIL,"Failed ");
				
			} else {
				System.out.println("Total no. of images loaded are " + imagesList.size());
				Reporter.log("Passed : All Images in the current page loaded successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	// Check the file from a specific directory
	public static void isFileDownloaded(WebDriver driver, String fileName) {
		String filePath = "C:\\Users\\ve40007843\\Downloads";
		File dir = new File(filePath);
		File[] dir_contents = dir.listFiles();

		for (int i = 0; i < dir_contents.length; i++) {
			if (dir_contents[i].getName().equals(fileName)) {
				System.out.println("PASS :File downloaded successfully " + fileName);
				Reporter.log("Passed : File downloaded successfully");
				break;
			} else {
				System.out.println("File not downloaded " + fileName);
				Reporter.log("Failed : File not downloaded");

			}

		}

	}

	/* Get the latest file from a specific directory */
	public File getLatestFilefromDir(WebDriver driver, String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		return lastModifiedFile;
	}

// Check the file from a specific directory with extension
	public boolean isFileDownloaded_Ext(WebDriver driver, String ext) {
		String downloadPath = "C:\\Users\\ve40007843\\Downloads";
		boolean flag = false;
		File dir = new File(downloadPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			flag = false;
		}

		for (int i = 1; i < files.length; i++) {
			if (files[i].getName().contains(ext)) {
				flag = true;
			}
		}
		return flag;
	}
	
	public static void verifyImagePresent(WebDriver driver, WebElement imageLocator) {
		Boolean ImagePresent = (Boolean) ((JavascriptExecutor) driver).executeScript(
				"return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0",
				imageLocator);
		int logoWidth = imageLocator.getSize().getWidth();
		System.out.println("Logo width : " + logoWidth + " pixels");

		int logoHeight = imageLocator.getSize().getHeight();
		System.out.println("Logo height : " + logoHeight + " pixels");

		if (!ImagePresent ) {
			Reporter.log("FAIL :" + imageLocator.getAttribute("class") + " Image not displayed ");
			
			System.out.println("FAIL :" + imageLocator.toString() + " Image not displayed ");
			softAssert.assertTrue(false);
		} else {
			if(logoHeight == 52 && logoWidth == 100) {
				Reporter.log("Pass : " + imageLocator.toString() + "  Image displayed with Width =" + logoWidth
						+ " and with Image Height : " + logoHeight);
				System.out.println("Pass : " + imageLocator.getAttribute("class") + " Image with Width =" + logoWidth
						+ " and with Image Height :" + logoHeight);
				softAssert.assertTrue(true);
				
			}else {
				Reporter.log("FAIL :" + imageLocator.getAttribute("class") + " Image not displayed with Width =" + logoWidth
						+ " and with Image Height : " + logoHeight);
				System.out.println("FAIL :" + imageLocator.getAttribute("class") + "Image not displayed with Width =" + logoWidth
						+ " and with Image Height : " + logoHeight);
				
			}
		
			
		}
		
	}
	
	public static void endofTestcase()
	{
		softAssert.assertAll();
	}
}
