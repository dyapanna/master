
package com.wipro.abbrelcare.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommonConstants {
	
		
	public static List<String> expTableHeadres = Arrays.asList("DATE,MORE");
	

}
