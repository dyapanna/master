package com.wipro.abbrelcare.regression.testcases;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.wipro.abbrelcare.pageObjects.LoginPagePages;
import com.wipro.abbrelcare.pageObjects.PMSettingsPage;
import com.wipro.abbrelcare.setup.BaseTestPage;
import com.wipro.abbrelcare.utility.AbbRelCareSynchronization;
import com.wipro.abbrelcare.utility.AbbRelCareVerification;
import com.wipro.abbrelcare.utility.CommonMethods;

public class PMSettings extends BaseTestPage {
	
	public static String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
	public static String roleName = RandomStringUtils.randomAlphabetic(10);
	public static String descName = "AutomationRole" + timeStamp;
	public static String randomVariable = RandomStringUtils.randomAlphabetic(5);
	/*public static String newMemberSurName = RandomStringUtils.randomAlphabetic(5);
	public static String newMemberEmployer = RandomStringUtils.randomAlphabetic(5);
	public static String newMemberJobDesc = RandomStringUtils.randomAlphabetic(5);
	public static String newMemberEmail = RandomStringUtils.randomAlphabetic(5);
	public static String skillName = RandomStringUtils.randomAlphabetic(5);
	public static String outageTypeNameName = RandomStringUtils.randomAlphabetic(5);*/
	String currnetlocation = System.getProperty("user.dir");
	// Verify ABB Project Manager or Project Support user is able to create a new role
	// review done

	@Test(priority = 1,description = "Verify ABB Project Manager or Project Support user is able to create a new")
	public void US_1_1_1_TC02() throws Exception {

		try {

			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			Thread.sleep(6000);
			PMSettingsPage pmSettings = new PMSettingsPage(driver);

			System.out.println("Actual List in Settings Page : " + pmSettings.linksListInSettings.getText());
			AbbRelCareVerification.verifyText(pmSettings.linksListInSettings, pmSettings.expEntityList);
			Thread.sleep(8000);
			pmSettings.linkMembersprivileges.click();
			Thread.sleep(10000);
			AbbRelCareSynchronization.waitForLoad(driver);
		
			AbbRelCareVerification.verifyTwoLists(pmSettings.linksListInMembersPriviliges, pmSettings.expMemberPrivilegePageTabs);

			pmSettings.linkRoles.click();
			Thread.sleep(8000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
		//	js.executeScript("arguments[0].scrollIntoView();", pmSettings.linkCreateNewRole);
			CommonMethods.scrollToWebElement(driver, pmSettings.linkCreateNewRole);
			pmSettings.linkCreateNewRole.click();
			Thread.sleep(4000);

			pmSettings.textBoxRoleName.sendKeys(roleName);
			pmSettings.textBoxDescription.sendKeys(descName);
			pmSettings.checkBoxProjectSetup.click();
			pmSettings.buttonDeployProjSlideBar_View.click();
			pmSettings.buttonCreateProjSlideBar_View.click();
			CommonMethods.scrollToWebElement(driver, pmSettings.buttonSave);
		//	js.executeScript("arguments[0].scrollIntoView();", pmSettings.buttonSave);
			pmSettings.buttonSave.click();
			Thread.sleep(4000);
			AbbRelCareVerification.verifyText(pmSettings.popupTextMsg, "Role created successfully!");
			pmSettings.buttonOK.click();
			Thread.sleep(4000);
			
			js.executeScript("arguments[0].scrollIntoView();", pmSettings.selectRole( roleName));
			AbbRelCareVerification.verifyElementPresent(driver, pmSettings.selectRole( roleName));
			pmSettings.selectRole( roleName).click();
			js.executeScript("arguments[0].scrollIntoView();", pmSettings.buttonDelete);
			pmSettings.buttonDelete.click();
			Thread.sleep(4000);
			AbbRelCareVerification.verifyText(pmSettings.textDeleteRole, "Delete role");
			pmSettings.buttonDeleteRole.click();
			Thread.sleep(4000);
			AbbRelCareVerification.verifyText(pmSettings.textRoleDeletedSuccess,"Role deleted successfully!");
			pmSettings.buttonOKRoleDeleted.click();
			
		} catch (NoSuchElementException ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
			Reporter.log("FAIL : Element not found");
		
		}
	}

//Verify that ABB Project Manager or Project Support user is able to edit the project	

	@Test(priority = 2,description="Verify PM or PS user is able to edit the project")
	public void US_2_1_2_TC01() throws Exception {
		try {

			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			Thread.sleep(6000);
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			PMSettingsPage pmSettings = new PMSettingsPage(driver);
			
			AbbRelCareVerification.verifyText(pmSettings.linksListInSettings, pmSettings.expEntityList);
			Thread.sleep(8000);
		
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", pmSettings.dropDownCurrency);

			String curCurrency = pmSettings.dropDownCurrency.getText();
			AbbRelCareVerification.verifyIsEnable(driver, pmSettings.dropDownCurrency);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(pmSettings.dropDownCurrency, "USD");
						
			js.executeScript("arguments[0].scrollIntoView();", pmSettings.buttonAssignMemberProjManager);
			pmSettings.buttonAssignMemberProjManager.click();
			Thread.sleep(4000);
			AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			pmSettings.selectManageMembers(driver, "Hari");
			pmSettings.buttonAssign.click();
			pmSettings.buttonAssignMemberProjSupport.click();
			
			
			//AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			Thread.sleep(4000);
			pmSettings.selectManageMembers(driver, "qa");
			pmSettings.buttonAssign.click();
			js.executeScript("arguments[0].scrollIntoView();", pmSettings.buttonAddNewOutage);
			int count = pmSettings.rowsOftableManageOutageTypes.size();
			
			if (count < 4) {
				js.executeScript("arguments[0].scrollIntoView();", pmSettings.buttonAddNewOutage);
				pmSettings.buttonAddNewOutage.click();
				Thread.sleep(4000);
				AbbRelCareVerification.verifyElementPresent(driver, pmSettings.textBoxOutageTypeName);
				pmSettings.textBoxOutageTypeName.sendKeys(randomVariable);
				pmSettings.textBoxDurationHours.sendKeys("2");
				CommonMethods.select_Option_In_DropDown_ByVisibleText(pmSettings.dropDownPeriodicityMonths, "24");

				pmSettings.buttonSaveAddNewOutageType.click();
				
				AbbRelCareVerification.verifyElementPresent(driver, pmSettings.popupWindowOutageTypeCreated);
				pmSettings.buttonOK.click();

			} else {
				Reporter.log("FAIL :Count is more than 4 we cant add");
				System.out.println("FAIL : Count is more than 4 we cant add");

			}

			pmSettings.selectManageMembers(driver, randomVariable);
			pmSettings.buttonEdit.click();
			AbbRelCareVerification.verifyElementPresent(driver, pmSettings.textBoxOutageTypeName);
			pmSettings.textBoxOutageTypeName.clear();
			pmSettings.textBoxOutageTypeName.sendKeys("Modified" + randomVariable);
			pmSettings.buttonSave.click();
			//AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			AbbRelCareVerification.verifyElementPresent(driver, pmSettings.popupWindowOutageTypeCreated);
			AbbRelCareVerification.verifyText(pmSettings.popupMsgSkillUpdatedSuccessfully,
					pmSettings.expOutagetypeupdatedsuccessfully);
			pmSettings.buttonOK.click();
			Thread.sleep(2000);
			pmSettings.selectManageMembers(driver, "Modified" + randomVariable);
			pmSettings.buttonDelete.click();
			AbbRelCareVerification.verifyElementPresent(driver, pmSettings.buttonCancel);
			pmSettings.buttonCancel.click();
		//	AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			AbbRelCareVerification.verifyElementNotPresent(driver, pmSettings.popupWindowOutageTypeCreated);

			pmSettings.selectManageMembers(driver, "Modified" + randomVariable);
			pmSettings.buttonDelete.click();
			pmSettings.buttonDelete.click();
		//	AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));

			AbbRelCareVerification.verifyElementPresent(driver, pmSettings.popupWindowOutageTypeCreated);
			AbbRelCareVerification.verifyText(pmSettings.textMsgOutageTypeDeleted,
					pmSettings.expOutagetypeupdatedsuccessfully);
			pmSettings.buttonOK.click();

		} catch (NoSuchElementException ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
			Reporter.log("FAIL : Element not found");
			
		}
	}

	// Verify creating a user with Execution Team Lead or Maintenance Technician  roles
//done
	@Test(priority = 3,description ="Verify creating a user with Execution Team Lead or Maintenance Technician  roles")
	public void US_1_2_1_TC01() throws Exception {

		try {

			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			//AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			Thread.sleep(12000);
			PMSettingsPage settings = new PMSettingsPage(driver);
			settings.linkMembersprivileges.click();
			Thread.sleep(10000);
			List<String> acttabsMembersPriv = new ArrayList<>();
			for(WebElement amp : settings.linksListInMembersPriviliges) {
				acttabsMembersPriv.add(amp.getText());
			}
			System.out.println("Tabs under Members & Privileges tab "+acttabsMembersPriv);
			AbbRelCareVerification.verifyTwoLists(acttabsMembersPriv, settings.expMemberPrivilegePageTabs);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", settings.buttonAddNewMember);
			settings.buttonAddNewMember.click();
		//	AbbRelCareSynchronization.waitForPageLoaderToClose(driver, By.xpath("//div[@class='loading-box']"));
			Thread.sleep(4000);
			AbbRelCareVerification.verifyText(settings.headerAddNewMember, settings.expAddnewmember);
			
			settings.textBoxName.sendKeys(randomVariable);
			settings.textBoxSurname.sendKeys(randomVariable);
			settings.textBoxEmployer.sendKeys(randomVariable);
			settings.textBoxJobposition.sendKeys(randomVariable);
			settings.textBoxEmail.sendKeys(randomVariable + "@wipro.com");
			Thread.sleep(200);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(settings.dropDownPhone, "+49");
			settings.textBoxPhone.sendKeys("9740342346");
			Thread.sleep(4000);
			//select  Execution Team Lead or Maintenance Technician role ?
			settings.selectCheckbox(settings.expProjectManager);
			Thread.sleep(1000);
			js.executeScript("arguments[0].scrollIntoView();", settings.visibleCheckbox( "Maintenance Manager"));
			settings.selectCheckbox("Maintenance Manager");
			Thread.sleep(1000);
			js.executeScript("arguments[0].scrollIntoView();", settings.buttonSaveAssignRolePrivileges);
			settings.buttonSaveAssignRolePrivileges.click();
			Thread.sleep(4000);
			AbbRelCareVerification.verifyElementPresent(driver, settings.popupWindowSkillAdded);
			settings.buttonOK_PopupSkills.click();
					
		} catch (NoSuchElementException ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
			Reporter.log("FAIL : Element not found");
			
		}

	}

	// Verify ABB Project Manager/Project support User is able to Create New Skill
//review done
	@Test(priority = 4, description ="Verify ABB Project Manager/Project support User is able to Create New Skil")
	public void US_1_3_1_TC01() throws Exception {
		try {

			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			Thread.sleep(6000);
			PMSettingsPage settings = new PMSettingsPage(driver);
			settings.linkMembersprivileges.click();
			Thread.sleep(10000);
			settings.linkSkills.click();
			Thread.sleep(4000);
			settings.buttonAddNewSkills.click();
			Thread.sleep(4000);
			List<String> actDefaultSkills = new ArrayList<String>();
			for (WebElement ds : settings.textDefaultSkillsList) {
				actDefaultSkills.add(ds.getText());
			}
			System.out.println("Default Skills on Page " + actDefaultSkills);

			settings.buttonAddNewSkills.click();
			Thread.sleep(4000);
			settings.textBoxAddNewSkill.sendKeys(randomVariable);
			settings.buttonSaveAddNewSkills.click();
			Thread.sleep(5000);
			AbbRelCareVerification.verifyElementPresent(driver, settings.popupWindowSkillAdded);
			AbbRelCareVerification.verifyText(settings.popupSuccessMsgSkillCreatedSuccessfully,
						settings.expSkillCreatedSuccessfully);
			settings.buttonOK_PopupSkills.click();
			

		} catch (NoSuchElementException ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
			Reporter.log("FAIL : Element not found");
			
		}
	}

	// Need AutoIt to be installed  as need to pass :Member with "Execution Team Lead" or " Maintenance Technician" role should be existing in the system
// reviewd done
	@SuppressWarnings("static-access")
	// Verify User is able to assign skill to the existing user
	@Test(priority = 5,description ="Verify User is able to assign skill to the existing user")
	public void US_1_2_6_TC02() throws Exception {
		
			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			Thread.sleep(6000);
			PMSettingsPage settings = new PMSettingsPage(driver);
			AbbRelCareVerification.verifyText(settings.linksListInSettings, settings.expEntityList);
			
			settings.linkMembersprivileges.click();
			Thread.sleep(10000);
			AbbRelCareSynchronization.waitForLoad(driver);
			ArrayList<String> actMemberPrivilegePageTabs = new ArrayList<>();
			for (WebElement mpHeaders : settings.linksListInMembersPriviliges) {
				actMemberPrivilegePageTabs.add(mpHeaders.getText());
			}
			System.out.println("Tabs under Members & Privileges are : " + actMemberPrivilegePageTabs);
			AbbRelCareVerification.verifyTwoLists(actMemberPrivilegePageTabs, settings.expMemberPrivilegePageTabs);

			// Pre require below user should exist
			
			AbbRelCareVerification.verifyMemberPresent(driver, settings.selectRole("new"));
			settings.selectManageMembers(driver, "new");
			settings.buttonEdit.click();
			Thread.sleep(4000);
			AbbRelCareVerification.verifyElementPresent(driver, settings.headerTextEditMember);
			AbbRelCareVerification.verifyElementPresent(driver, settings.tabLinkExecutionTeam);
			AbbRelCareVerification.verifyElementPresent(driver, settings.tabLinkSkillsCertificates);
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", settings.tabLinkSkillsCertificates);
			settings.tabLinkSkillsCertificates.click();
			Thread.sleep(4000);
			AbbRelCareVerification.verifyElementPresent(driver, settings.buttonAssignSkill);
			AbbRelCareVerification.verifyElementPresent(driver, settings.buttonEdit_AssignSkill);
			AbbRelCareVerification.verifyElementPresent(driver, settings.buttonsAssignSkillDelete);
			
			settings.buttonAssignSkill.click();
			Thread.sleep(4000);
			AbbRelCareVerification.verifyElementPresent(driver, settings.headerTextManagerUserSkill);
			AbbRelCareVerification.verifyText(settings.textLabelSkillName,settings.expSkillname);
			AbbRelCareVerification.verifyText(settings.textLabelLevelOfExpertise,settings.expLevelofexpertise);
			
			CommonMethods.select_Option_In_DropDown_ByValue(settings.dropDownSkillName, 2);
			
			CommonMethods.dragAndDrop(settings.sliderLeveExpert1, settings.sliderLeveExpert3);
			//The below 2 steps need autoit to be installed
			/*settings.buttonAttachDocument.click();
			Runtime.getRuntime().exec("C\\ABB\\FileUpload.exe");*/
			AbbRelCareVerification.verifyText(settings.selectText(driver, "Hbird.jpg"), "Hbird.jpg");
		//	settings.buttonAttachDocument.sendKeys(currnetlocation+"/Images/hockey.jpg");
			
			CommonMethods.select_Option_In_DropDown_ByValue(settings.dropDownValidityMonth, 4);
			CommonMethods.select_Option_In_DropDown_ByValue(settings.dropDownValidityYear, 4);
			
			settings.buttonAssign.click();
			

	
	}

//Verify ABB Project Manager/Project support  is able to update the existing Customised skills	
//done
	@Test(priority = 6)
	public void US_1_3_2_TC01() throws Exception {
		try {

			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			Thread.sleep(6000);
			PMSettingsPage settings = new PMSettingsPage(driver);
			settings.linkMembersprivileges.click();
			Thread.sleep(8000);
			settings.linkSkills.click();
			Thread.sleep(4000);
			settings.buttonAddNewSkills.click();
			Thread.sleep(2000);
			settings.textBoxAddNewSkill.sendKeys(randomVariable);
			settings.buttonSaveAddNewSkills.click();
			Thread.sleep(1000);
			settings.buttonOK_PopupSkills.click();
			settings.selectCustomisedSkill( randomVariable);
			settings.buttonEditCustomisedSkills.click();
			Thread.sleep(200);
			settings.textBoxAddNewSkill.clear();
			settings.textBoxAddNewSkill.sendKeys("Modified" + randomVariable);
			settings.buttonSaveEditSkill.click();
			Thread.sleep(2000);
			
			AbbRelCareVerification.verifyElementPresent(driver, settings.popupWindowSkillAdded);
			AbbRelCareVerification.verifyText(settings.popupMsgSkillUpdatedSuccessfully,
			settings.expSkillUpdatedSuccessfully);
			settings.buttonOK_PopupSkills.click();
			
			

		} catch (NoSuchElementException ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
			Reporter.log("FAIL : Element not found");
			
		}
	}

	// Verify ABB Project Manager is able to update the existing skill in Edit member page
	// Prerequiste : User should have roles of Maintenance information
	@Test(priority = 7,description = "Project Manager is able to update the existing skill in Edit member page")
	public void US_1_3_2_TC02() throws Exception {
		
			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			//Thread.sleep(8000);
			AbbRelCareSynchronization.waitForJSandJQueryToLoad(driver);
			PMSettingsPage settings = new PMSettingsPage(driver);
			AbbRelCareSynchronization.waitElementForVisibleById(driver, settings.linkMem);
			
			settings.linkMembersprivileges.click();
			
			Thread.sleep(8000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", settings.selectText(driver, "main"));
			settings.selectManageMembers(driver, "main");
			settings.buttonEdit.click();
			Thread.sleep(4000);
			
			js.executeScript("arguments[0].scrollIntoView();", settings.tabLinkSkillsCertificates);
			settings.tabLinkSkillsCertificates.click();
			Thread.sleep(4000);
			AbbRelCareSynchronization.waitElementForVisibleById(driver, settings.by1);
			settings.buttonAssignSkill.click();
			Thread.sleep(4000);
			for(WebElement acl : settings.dropDownSkillNameList ) {
				System.out.println("Actual skills in List :"+acl.getText());
			}
			
			
			CommonMethods.select_Option_In_DropDown_ByVisibleText(settings.dropDownSkillName, settings.dropDownSkillNameList.get(1).getText());
			//String skill = settings.textofdropDownSkillName.getAttribute("name");
			System.out.println("Selected skill :"+settings.dropDownSkillNameList.get(1).getText());
			settings.buttonAssign.click();
			Thread.sleep(6000);
			Reporter.log("New Skill add successfully ");
			System.out.println("New Skill add successfully");
			
			settings.selectSkillName(driver, settings.dropDownSkillNameList.get(1).getText());
			settings.buttonEdit_AssignSkill.click();
			Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(settings.dropDownSkillName, settings.dropDownSkillNameList.get(2).getText());
			//String mskill = settings.textofdropDownSkillName.getAttribute("value");
			System.out.println("Modified skill :"+settings.dropDownSkillNameList.get(2).getText());
			Reporter.log("Trying to update existing Skills and certificates");
			System.out.println("Trying to update existing Skills and certificates");
			settings.buttonAssign.click();
			Thread.sleep(4000);
			
			AbbRelCareVerification.verifyElementPresent(driver, settings.selectTextName(driver, settings.dropDownSkillNameList.get(1).getText()));
			Reporter.log("Skills updated Successfully");
			AbbRelCareVerification.endofTestcase();
		
	}

//Need clarification on deleting		
//Verify ABB Project Manager is able to remove the skill allocated	
	@Test(priority = 8)
	public void US_1_3_3_TC01() throws InterruptedException {
		try {

			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			Thread.sleep(6000);
			PMSettingsPage settings = new PMSettingsPage(driver);
			settings.linkMembersprivileges.click();
			Thread.sleep(18000);
			settings.selectManageMembers(driver, "testpng");
			settings.buttonEdit.click();
			Thread.sleep(4000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", settings.tabLinkSkillsCertificates);
			settings.tabLinkSkillsCertificates.click();
			Thread.sleep(4000);
			settings.buttonAssignSkill.click();
			Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(settings.dropDownSkillName, "Java");
			settings.buttonAssign.click();
			Thread.sleep(4000);
			settings.selectSkillName(driver, "Java");
			settings.buttonEdit_AssignSkill.click();
			Thread.sleep(4000);
			settings.selectSkillName(driver, "Java");
			settings.buttonDelete_AssignSkill.click();
			Thread.sleep(4000);
			try {
				AbbRelCareVerification.verifyElementPresent(driver, settings.popupWindowSkillAdded);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
				Reporter.log("FAIL : Element not found");
				
			}
		} catch (NoSuchElementException ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
			Reporter.log("FAIL : Element not found");
			
		}
	}

//Verify ABB Project Manager is able to remove the skill in Edit member page	
	@Test(priority = 9)
	public void US_1_3_3_TC03() throws InterruptedException {
		try {

			LoginPagePages loginPage = new LoginPagePages(driver);
			loginPage.loginAbbRelCare(pmuserName, passWord);
			Thread.sleep(6000);
			PMSettingsPage settings = new PMSettingsPage(driver);
			settings.linkMembersprivileges.click();
			Thread.sleep(18000);
			settings.selectManageMembers(driver, "testpng");
			settings.buttonEdit.click();
			Thread.sleep(4000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", settings.tabLinkSkillsCertificates);
			settings.tabLinkSkillsCertificates.click();
			Thread.sleep(4000);
			settings.buttonAssignSkill.click();
			Thread.sleep(4000);
			CommonMethods.select_Option_In_DropDown_ByVisibleText(settings.dropDownSkillName, "Java");
			settings.buttonAssign.click();
			Thread.sleep(4000);
			settings.selectSkillName(driver, "Java");
			settings.buttonEdit_AssignSkill.click();
			Thread.sleep(4000);
			settings.selectSkillName(driver, "Java");
			settings.buttonDelete_AssignSkill.click();
			Thread.sleep(4000);
			try {
				AbbRelCareVerification.verifyElementPresent(driver, settings.popupWindowSkillAdded);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
				Reporter.log("FAIL : Element not found");
				
			}
		} catch (NoSuchElementException ex) {
			ex.printStackTrace();
			System.out.println(ex.getMessage());
			Reporter.log("FAIL : Element not found");
			
		}
	}


}
