package com.wipro.abbrelcare.utility;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.wipro.abbrelcare.setup.BaseTestPage;

public class AbbRelCareSynchronization {
	
	private static final long DEFAULT_TIMEOUT = 60;

	public static void waitElementForVisible(WebDriver driver, WebElement locator) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			Reporter.log(locator.toString() + ": Loaded successfully");
			
		}catch (StaleElementReferenceException | TimeoutException | NoSuchElementException e) {

		}
		
	}
	
	public static void waitElementForVisibleById(WebDriver driver, By elementValue) throws InterruptedException {
		long time = System.currentTimeMillis()+80000;
		while(true) {
			if(driver.findElement(elementValue).isDisplayed())
				break;
			
			Thread.sleep(10);
			if(time <System.currentTimeMillis()) {
				throw new NoSuchElementException(" Item " +elementValue + "is not displayed");
			}
		}
		
		
	}

	// Method to wait untill loader disappears 	
		final public static boolean waitForPageLoaderToClose(WebDriver driver, final By by) {
		    try {
		        driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);

		        WebDriverWait wait = new WebDriverWait(BaseTestPage.driver, DEFAULT_TIMEOUT);

		        boolean present = wait.until(ExpectedConditions.invisibilityOfElementLocated(by));

		        return present;
		    } catch (Exception e) {
		        return false;
		    } finally {
		        driver.manage().timeouts()
		                .implicitlyWait(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
		    }
		}
	public static boolean waitForPageToBeReady(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, 100);
		ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				try {
					return((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
				}catch(Exception e) {
					return false;
				}
			}
			};
			return wait.until(jsLoad);
		
	}
	
	
	
/*	public static void waitElement(WebDriver driver, WebElement locator) {
		long time = System.currentTimeMillis();
		long sysTime = System.currentTimeMillis() + 2000;
		while (true && time < sysTime) {
			try {
				if (locator.isDisplayed()) {
					Reporter.log(locator.toString() + ": Loaded successfully");
					break;
				}
			} catch (StaleElementReferenceException | TimeoutException | NoSuchElementException e) {

			}

		}

	}*/

	public static void waitElement(WebDriver driver, WebElement locator) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			wait.until(ExpectedConditions.visibilityOf(locator));

		} catch (StaleElementReferenceException | TimeoutException | NoSuchElementException e) {

			System.out.println(locator.toString() + "Element not found");
		}

	}
	
	
	public static void waitisElementClickable(WebDriver driver, WebElement locator) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			wait.until(ExpectedConditions.elementToBeClickable(locator));
		} catch (StaleElementReferenceException | TimeoutException | NoSuchElementException e) {

		}

	}

	public static void waitIsElementVisible(WebDriver driver, By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (StaleElementReferenceException | TimeoutException | NoSuchElementException e) {

		}

	}

	public static void waitForinvisibility(WebDriver driver, By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			String text = ((WebElement) locator).getText();
			wait.until(ExpectedConditions.invisibilityOfElementWithText(locator, text));

		} catch (StaleElementReferenceException | TimeoutException | NoSuchElementException e) {

		}

	}
	
	@SuppressWarnings("deprecation")
	public static void until(WebDriver driver, Function<WebDriver, Boolean> waitCondition, Long timeoutInSeconds){
		 WebDriverWait webDriverWait = new WebDriverWait(driver, timeoutInSeconds);
		 webDriverWait.withTimeout(timeoutInSeconds, TimeUnit.SECONDS);
	
		 try{
		 webDriverWait.until(waitCondition);
		 }catch (Exception e){
		 System.out.println(e.getMessage());
		 }          
		 }
	
		
// Jquery to load page
	public static boolean waitForJSandJQueryToLoad(WebDriver driver) {

	    WebDriverWait wait = new WebDriverWait(driver, 60);

	    // wait for jQuery to load
	    ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
	      @Override
	      public Boolean apply(WebDriver driver) {
	        try {
	          return ((Long)((JavascriptExecutor)driver).executeScript("return jQuery.active") == 0);
	        }
	        catch (Exception e) {
	          // no jQuery present
	          return true;
	        }
	      }
	    };

	    // wait for Javascript to load
	    ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
	      @Override
	      public Boolean apply(WebDriver driver) {
	        return ((JavascriptExecutor)driver).executeScript("return document.readyState")
	        .toString().equals("complete");
	      }
	    };

	  return wait.until(jQueryLoad) && wait.until(jsLoad);
	}
	
	
 public static void waitForLoad(WebDriver driver) {
     ExpectedCondition<Boolean> pageLoadCondition = new
             ExpectedCondition<Boolean>() {
                 public Boolean apply(WebDriver driver) {
                     return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
                 }
             };
     WebDriverWait wait = new WebDriverWait(driver, 30);
     wait.until(pageLoadCondition);
 }
 
}
