package com.wipro.abbrelcare.pageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.wipro.abbrelcare.setup.BasePage;
import com.wipro.abbrelcare.utility.AbbRelCareSynchronization;


public class LoginPagePages extends BasePage {

	JavascriptExecutor js;

	public LoginPagePages(WebDriver driver) {
		super(driver);
		// this.driver=driver;

	}
	
	@FindBy(xpath = "//div[@class='logo']")
	public WebElement logoABB;

	@FindBy(name = "state.form.username")
	public WebElement textBoxEmail;

	@FindBy(name = "state.form.password")
	public WebElement textBoxPassword;

	@FindBy(xpath = "//button[contains(text(),'Log in')]")
	public WebElement buttonLogin;
	
	@FindBy(xpath = "//button[contains(text(),'Log in')]")
	public WebElement linkForgotPassword;

	public void loginAbbRelCare(String userName, String passWord) throws InterruptedException {

		textBoxEmail.sendKeys(userName);
		textBoxPassword.sendKeys(passWord);
		buttonLogin.click();
		Thread.sleep(5000);

	}

	public void waitForPageLoad(WebDriver driver) {
		AbbRelCareSynchronization.waitElementForVisible(driver, textBoxEmail);
	}

}
