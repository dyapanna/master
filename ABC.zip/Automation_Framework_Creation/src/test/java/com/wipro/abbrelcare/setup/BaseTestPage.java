package com.wipro.abbrelcare.setup;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.wipro.abbrelcare.listeners.TestListeners;
import com.wipro.abbrelcare.listeners.WebEventListener;
import com.wipro.abbrelcare.utility.ReadFileData;

public class BaseTestPage extends ReadFileData {

	public WebDriver edriver;
	public WebDriverWait wait;
	public static EventFiringWebDriver driver;
	public WebEventListener eventListener;
	public String currnetlocation = System.getProperty("user.dir");
	public String downloadFilepath = currnetlocation + "/Downloads/";
	public static int tccount = 0;

	@Parameters({ "browser" })
	@BeforeMethod
	public void openBrowser(@Optional("chrome") String browser) {
		ExtentReports extent;
		ExtentTest logger;
		tccount++;
		//System.out.println("method name:" + result.getMethod().getMethodName());
		try {

			if (browser.equalsIgnoreCase("Firefox")) {
				System.out.println("Launching Firefox browser");
				System.setProperty("webdriver.gecko.driver", currnetlocation + "/Drivers/geckodriver.exe");
				edriver = new FirefoxDriver();
				edriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			} else if (browser.equalsIgnoreCase("chrome")) {
				ChromeOptions options = new ChromeOptions();
				
				options.addArguments("disable-infobars");
				System.out.println("Launching Chrome browser");
				System.setProperty("webdriver.chrome.driver", currnetlocation + "/Drivers/chromedriver.exe");
				edriver = new ChromeDriver(options);
				edriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				edriver.manage().window().maximize();
				
							
			} else if (browser.equalsIgnoreCase("IE")) {
				System.out.println("Launching IE browser");
				System.setProperty("webdriver.ie.driver", currnetlocation + "/Drivers/IEDriverServer.exe");
				edriver = new InternetExplorerDriver();
				edriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else if (browser.equalsIgnoreCase("Edge")) {
				System.out.println("Launching Microsoft Edge browser");
				System.setProperty("webdriver.edge.driver", currnetlocation + "/Drivers/MicrosoftWebDriver.exe");
				edriver = new EdgeDriver();
				edriver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			}
		} catch (WebDriverException e) {
			System.out.println(e.getMessage());

			/*
			 * LoginPage loginPage = new LoginPage(driver);
			 * loginPage.loginInteliCare(userName, passWord);
			 */
		}

		driver = new EventFiringWebDriver(edriver);
		eventListener = new WebEventListener();
		driver.register(eventListener);
		driver.get(getUrl());

	}

	@AfterMethod
	public void tear() {
		driver.quit();

	}

	@AfterSuite
	public void createReport() {
		System.out.println("Number of tC executed : " + tccount);

	
	/*	SLog sl = new SLog();
		sl.createWDBLog(0, testcount);*/

	}

	public WebDriver getDriver() {
		return driver;
	}

}
