package com.wipro.abbrelcare.pageObjects;

import org.openqa.selenium.WebDriver;

import com.wipro.abbrelcare.setup.BasePage;

public class HomePages extends BasePage{

	public HomePages(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public String expURL = "https://abbrcsqaui.azurewebsites.net/#/dashboard";

}
