package com.wipro.abbrelcare.pageObjects;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.wipro.abbrelcare.setup.BasePage;

public class PMSettingsPage extends BasePage {

	private WebDriver driver;

	public PMSettingsPage(WebDriver driver) {
		super(driver);
		this.driver = driver;

	}

	public List<String> expMemberPrivilegePageTabs = Arrays.asList("Members", "Execution teams", "Roles", "Skills");
	public String expEditMember = "Edit member";
	public String expExecutionTeam = "Execution Team";
	public String expSkillsAndCertificates = "Skills & certificates";
	public String expSkillCreatedSuccessfully = "Skill created successfully!";
	public String expSkillUpdatedSuccessfully = "Skill updated successfully!";
	public String expEntityList = "Project entities\r\n" + "Project modelling\r\n" + "Task criterias\r\n"
			+ "Members & privileges";
	public String expProjectManager = "Project Manager (ABB)";

	public By linkMem = By.linkText("Members & privileges");

	@FindBy(xpath = "//ul[@class='links']")
	public WebElement linksListInSettings;

	@FindBy(xpath = "//h3[text()='Settings']")
	public WebElement headerTextSettings;

	@FindBy(xpath = "//span[text()='Members & privileges']")
	public WebElement linkMembersprivileges;

	@FindBy(xpath = "//div[@class='all-user-table']")
	public List<WebElement> tableRowsManageMembers;

	// Project entities Project Client details

	@FindBy(xpath = "//div[@class='row']")
	public List<WebElement> textClientDetails;

	@FindBy(xpath = "//div[label[text()='Currency']]//select")
	public WebElement dropDownCurrency;

	@FindBy(xpath = "////h5[text()='Project support']/preceding-sibling::a//i")
	public WebElement buttonAssignMemberProjManager;

	@FindBy(xpath = "//h5[text()='Project support']/following-sibling::a//i")
	public WebElement buttonAssignMemberProjSupport;

	/*
	 * @FindBy(linkText = "//span[text()='Add new outage']") public WebElement
	 * windowAddnewoutagetype;
	 */

	@FindBy(xpath = "//a[text()='Delete']")
	public WebElement buttonDelete;

	@FindBy(xpath = "//span[text()='Delete role']")
	public WebElement textDeleteRole;

	@FindBy(xpath = "//span[text()='Role deleted successfully!']")
	public WebElement textRoleDeletedSuccess;

	@FindBy(xpath = "//a[text()='OK']")
	public WebElement buttonOKRoleDeleted;

	@FindBy(xpath = "//span[text()='Delete role']/../..//a[text()='Delete']")
	public WebElement buttonDeleteRole;

	@FindBy(xpath = "//a[text()='Cancel']")
	public WebElement buttonCancel;

	@FindBy(xpath = "//span[text()='Delete outage type']")
	public WebElement textDeleteOutageType;

	// Manage Outage types

	@FindBy(xpath = "//datatable-body[@class='datatable-body']")
	public List<WebElement> tableManageOutageTypes;

	@FindBy(xpath = "//datatable-row-wrapper")
	public List<WebElement> rowsOftableManageOutageTypes;

	@FindBy(xpath = "//datatable-row-wrapper[1]")
	public WebElement firstrowsOftableManageOutageTypes;

	@FindBy(xpath = "//span[text()='Are you sure you want to delete the outage type?']/../..//a[text()='Delete']")
	public WebElement buttonDeleteOfOutageType;

	// Add new outage type

	public static String expOutagetypeupdatedsuccessfully = "Outage type updated successfully!";

	@FindBy(xpath = "//span[text()='Add new outage']")
	public WebElement buttonAddNewOutage;

	@FindBy(xpath = "//label[text()='Outage type name']/..//input")
	public WebElement textBoxOutageTypeName;

	@FindBy(xpath = "//label[text()='Duration / Hours']/..//input")
	public WebElement textBoxDurationHours;

	@FindBy(xpath = "//label[text()='Periodicity / Months']/..//select")
	public WebElement dropDownPeriodicityMonths;

	@FindBy(xpath = "//app-successpopup")
	public WebElement popupWindowOutageTypeCreated;

	@FindBy(xpath = "//span[text()='Outage type created successfully!']")
	public WebElement textMsgOutageTypeCreated;

	@FindBy(xpath = "//span[text()='Outage type updated successfully!']")
	public WebElement textMsgOutageTypeUpdated;

	@FindBy(xpath = "//span[text()='Outage type deleted successfully!']")
	public WebElement textMsgOutageTypeDeleted;

	@FindBy(xpath = "//button[text()='Save']")
	public WebElement buttonSaveAddNewOutageType;

	// Members & priviliges
	@FindBy(xpath = "//a[@class='nav-link active']")
	public WebElement linkMembers;
	@FindBy(xpath = "//li[@class='nav-item']")
	public List<WebElement> linksListInMembersPriviliges;

	@FindBy(xpath = "//a[starts-with(@id,'ngb-tab-') and contains(text(),'Execution')]")
	public WebElement linkExecutionTeams;

	@FindBy(xpath = "//a[starts-with(@id,'ngb-tab') and contains(text(),'Roles')]")
	public WebElement linkRoles;

	@FindBy(xpath = "//a[starts-with(@id,'ngb-tab-') and contains(text(),'Skills')]")
	public WebElement linkSkills;

	/*
	 * @FindBy(xpath = "//div[@class='tabs-member-container']") public
	 * MembersAndPriviliges mandp;
	 * 
	 * 
	 * public class MembersAndPriviliges{
	 * 
	 * 
	 * 
	 * }
	 */

	// Members page
	@FindBy(xpath = "//span[contains(text(),'Add new member')]")
	public WebElement buttonAddNewMember;

	@FindBy(xpath = "//a[text()='Edit']")
	public WebElement buttonEdit;

	// Add new member
	public String expAddnewmember = "Add new member";

	@FindBy(xpath = "//span[text()='Name']/../following-sibling::div/input")
	public WebElement textBoxName;

	@FindBy(xpath = "//h3[text()='Add new member']")
	public WebElement headerAddNewMember;

	@FindBy(xpath = "//span[text()='Surname']/../following-sibling::div/input")
	public WebElement textBoxSurname;

	@FindBy(xpath = "//span[text()='Employer']/../following-sibling::div/input")
	public WebElement textBoxEmployer;

	@FindBy(xpath = "//span[text()='Job position']/../following-sibling::div/input")
	public WebElement textBoxJobposition;

	@FindBy(xpath = "//span[text()='Email']/../following-sibling::div/input")
	public WebElement textBoxEmail;

	@FindBy(xpath = "//span[text()='Phone']/../following-sibling::div[@class='fs-val fs-val-fx']/div/select")
	public WebElement dropDownPhone;

	@FindBy(xpath = "//span[text()='Phone']/../following-sibling::div[@class='fs-val fs-val-fx']/div/input")
	public WebElement textBoxPhone;

	// Assign role & priviliges
	@FindBy(xpath = "//span[text()='Project Support']")
	public WebElement checkBoxProjectSupport;

	@FindBy(xpath = "//a[text()='Save']")
	public WebElement buttonSaveAssignRolePrivileges;

	// Roles

	@FindBy(xpath = "//div[@class='card-header']")
	public List<WebElement> headerTextListInRoles;

	@FindBy(xpath = "//div[@class='card-role-wrap add-new']")
	public WebElement textCreateNewRole;

	@FindBy(xpath = "//span[text()='Policy SME (ABB)']")
	public WebElement linkPolicySME;

	@FindBy(xpath = "//i[@class='icon icon-add-new']")
	public WebElement linkCreateNewRole;

	// Create new role

	@FindBy(xpath = "//div[contains(text(),'Role Name ')]")
	public WebElement textRoleName;

	@FindBy(xpath = "//div[text()='Role Name ']/following-sibling::div/input")
	public WebElement textBoxRoleName;

	@FindBy(xpath = "//span[contains(text(),'Description')]")
	public WebElement textDescription;

	@FindBy(xpath = "//div[@class='fs-val']/textarea")
	public WebElement textBoxDescription;

	@FindBy(xpath = "//a[@id='ngb-tab' and contains(text(),'Privilegs')]")
	public WebElement linkPrivilegs;

	@FindBy(xpath = "//a[@id='ngb-tab-8']")
	public WebElement linkDashboard;

	// Privileges

	@FindBy(xpath = "//header[@class='pg-head']")
	public List<WebElement> headerText_Privileges;

	@FindBy(xpath = "//a[@id='ngb-tab-8']")
	public List<WebElement> checkBox_Privileges;

	// Manage System

	@FindBy(xpath = "//span[text()='Deploy Projects']")
	public WebElement textDeployProjects;

	@FindBy(xpath = "//span[text()='Create Projects']")
	public WebElement textCreateProjects;

	@FindBy(xpath = "//div[@class='three-state-slide']")
	public List<WebElement> slideBar_ManageSystem;

	@FindBy(xpath = "//span[text()='Hide']")
	public List<WebElement> slideBarText_Hide;

	@FindBy(xpath = "//span[text()='Deploy Projects']/following-sibling::div//div/span[text()='View']")
	public WebElement buttonDeployProjSlideBar_View;

	@FindBy(xpath = "//span[text()='Create Projects']/following-sibling::div//div/span[text()='View']")
	public WebElement buttonCreateProjSlideBar_View;

	@FindBy(xpath = "//span[text()='Edit']")
	public List<WebElement> slideBarText_Edit;

	// Project Setup

	@FindBy(xpath = "//i[@class='icon icon-checkbox']/following-sibling::span[text()='Project Setup']")
	public WebElement checkBoxProjectSetup;

	@FindBy(xpath = "//div[@class='three-state-slide']")
	public List<WebElement> slideBar_ProjectSetup;

	@FindBy(xpath = "//i[@class='icon icon-back']")
	public WebElement linkBackButtonIcon;

	@FindBy(xpath = "//span[text()='Not saved']")
	public WebElement textPopUpNotSaved;

	@FindBy(xpath = "//a[@class='btn btn-cancel']")
	public WebElement buttonOK;

	@FindBy(xpath = "//a[text()='Save']")
	public WebElement buttonSave;

	@FindBy(xpath = "//span[text()='Role created successfully!']")
	public WebElement popupTextMsg;

	// Edit member

	@FindBy(xpath = "//h3[text()='Edit member']")
	public WebElement headerTextEditMember;

	@FindBy(xpath = "//a[contains(text(),' Execution Team')]")
	public WebElement tabLinkExecutionTeam;

	@FindBy(xpath = "//a[contains(text(),' Skills & certificates')]")
	public WebElement tabLinkSkillsCertificates;

	public By by1 = By.xpath("//span[text()='Assign skill']");

	@FindBy(xpath = "//span[text()='Assign skill']")
	public WebElement buttonAssignSkill;

	@FindBy(xpath = "//div[@class='skill-buttons']/a[text()='Delete']")
	public WebElement buttonsAssignSkillDelete;

	@FindBy(xpath = "//div[@class='skill-buttons']/a[text()='Edit']")
	public WebElement buttonEdit_AssignSkill;

	@FindBy(xpath = "//div[@class='skill-buttons']/a[text()='Delete']")
	public WebElement buttonDelete_AssignSkill;

	@FindBy(xpath = "//span[text()='Assign skill']/../..//div[@class='item']")
	public List<WebElement> text_AssignedSkillNameList;

	// Manager user skill

	public static String expSkillname = "Skill name";
	public static String expLevelofexpertise = "Level of expertise";

	@FindBy(xpath = "//span[contains(text(),'Manager user skill')]")
	public WebElement headerTextManagerUserSkill;

	@FindBy(xpath = "//div[@class='label']")
	public List<WebElement> textLabelsOfManagerUserSkill;

	@FindBy(xpath = "//div[contains(text(),'Skill name')]")
	public WebElement textLabelSkillName;

	@FindBy(xpath = "//div[contains(text(),'Level of expertise')]")
	public WebElement textLabelLevelOfExpertise;

	@FindBy(xpath = "//span[text()='File']/../..//select[1]")
	public WebElement dropDownValidityMonth;

	@FindBy(xpath = "//span[text()='File']/../..//select[2]")
	public WebElement dropDownValidityYear;

	@FindBy(xpath = "//div[text()='Skill name']/following-sibling::select")
	public WebElement dropDownSkillName;

	@FindBy(xpath = "//div[text()='Skill name']/following-sibling::select/option")
	public List<WebElement> dropDownSkillNameList;

	@FindBy(xpath = "//div[text()='Skill name']/following-sibling::select/option[1]")
	public WebElement textofdropDownSkillName;

	@FindBy(xpath = "//div[@class='slider-labels']/span[1]")
	public WebElement sliderLeveExpert1;

	@FindBy(xpath = "//div[@class='slider-labels']/span[2]")
	public WebElement sliderLeveExpert2;

	@FindBy(xpath = "//div[@class='slider-labels']/span[3]")
	public WebElement sliderLeveExpert3;

	@FindBy(xpath = "//div[@class='slider-labels']/span[4]")
	public WebElement sliderLeveExpert4;

	@FindBy(xpath = "//div[@class='slider-labels']/span[5]")
	public WebElement sliderLeveExpert5;

	@FindBy(xpath = "//div[text()='Skill name']/following-sibling::div//span[@class='ng5-slider-span ng5-slider-pointer ng5-slider-pointer-min']")
	public WebElement iconSliderLevelOfExpertise;

	@FindBy(xpath = "//span[text()='Attach document']")
	public WebElement buttonAttachDocument;

	@FindBy(xpath = "//a[text()='Assign']")
	public WebElement buttonAssign;

	@FindBy(xpath = "//a[text()='Assign']")
	public WebElement textAssignSkill;

	@FindBy(xpath = "//a[@class='btn btn-delete']")
	public WebElement buttonDeleteOfManagerUserSkill;

	@FindBy(xpath = "//div[text()='Validity']")
	public WebElement textValidity;

	@FindBy(xpath = "//span[text()='File']")
	public WebElement textFile;

	// Skills

	@FindBy(xpath = "//span[text()='Default skills']")
	public WebElement textDefaultSkills;

	@FindBy(xpath = "//span[text()='Customised skills']")
	public WebElement textCustomisedSkills;

	@FindBy(xpath = "//span[text()='Default skills']/../..")
	public List<WebElement> textDefaultSkillsList;

	@FindBy(xpath = "//a[@class='item add-new']")
	public WebElement buttonAddNewSkills;

	@FindBy(xpath = "//span[text()='*Name']/../../input")
	public WebElement textBoxAddNewSkill;

	@FindBy(xpath = "//a[@class='btn btn-save']")
	public WebElement buttonSaveAddNewSkills;

	@FindBy(xpath = "//app-successpopup")
	public WebElement popupWindowSkillAdded;

	@FindBy(xpath = "//a[@class='btn btn-save']")
	public WebElement popupSuccessMsgSkillCreatedSuccessfully;

	@FindBy(xpath = "//span[text()='Skill updated successfully!']")
	public WebElement popupMsgSkillUpdatedSuccessfully;

	@FindBy(xpath = "//a[@class='btn btn-cancel']")
	public WebElement buttonOK_PopupSkills;

	@FindBy(xpath = "//a[text()='Edit']")
	public WebElement buttonEditCustomisedSkills;

	@FindBy(xpath = "//a[@class='btn btn-save']")
	public WebElement buttonSaveEditSkill;

	public void selectCustomisedSkill(String skillNAme) {
		driver.findElement(By.xpath("//span[text()='" + skillNAme + "']/..//i[@class='icon icon-checkbox']")).click();
	}

	public void selectCheckbox(String skillName) {
		driver.findElement(By.xpath("//span[contains(text(),'" + skillName + "')]/..//i[@class='icon icon-checkbox']"))
				.click();
	}

	public WebElement visibleCheckbox(String skillName) {
		return driver.findElement(
				By.xpath("//span[contains(text(),'" + skillName + "')]/..//i[@class='icon icon-checkbox']"));

	}

	// Method to select Member from Manage members
	public WebElement selectRole(String roleName) {
		return driver.findElement(By.xpath("//span[text()='" + roleName + "']"));
	}

	// Method to select Member from Manage members
	public WebElement selectText(WebDriver driver, String textName) {
		return driver.findElement(By.xpath("//span[text()='" + textName + "']"));
	}

	// Method to select Member from Manage members
	public static void selectSkillName(WebDriver driver, String skillName) {
		driver.findElement(By.xpath("//span[contains(text(),'" + skillName + "')]/..//i[@class='icon icon-checkbox']"))
				.click();
	}

	// Method to select Member from Manage members
	public static WebElement selectTextName(WebDriver driver, String textName) {
		return driver.findElement(By.xpath("//span[text()='" + textName + "']"));
	}

	// Method to select Member from Manage members
	public static void selectManageMembers(WebDriver driver, String memberName) {
		driver.findElement(By.xpath("//span[text()='" + memberName + "']/../../../..//i[@class='icon icon-checkbox']"))
				.click();
	}

	public void clickOnHideViewEdit(String projNames, String rolesHideEditView) {
		driver.findElement(
				By.xpath("//div[span[text()='" + projNames + "']]//span[text()='" + rolesHideEditView + "']"));

	}

}
