package com.wipro.abbrelcare.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.wipro.abbrelcare.setup.BasePage;
import com.wipro.abbrelcare.setup.BaseTestPage;

public class SystemManagerAllProjects extends BasePage{

	public SystemManagerAllProjects(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public String expTitle = "All projects";
	
	@FindBy(xpath = "//h3[contains(text(),'All projects')]")
	public WebElement textAllProjects;
	
	@FindBy(xpath = "//a[@href='#/dashboard/create-project']")
	public WebElement linkCreateNew;

	
	
}
